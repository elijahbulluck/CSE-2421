/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE
   STRICTLY ADHERED TO THE TENURES OF THE
   OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
 
struct Cost {
float wholesalePrice;
float retailPrice;
int wholesaleQuantity;
int retailQuantity;
};
struct Data {
char item[50];
char department[30];
 int stockNumber;
 struct Cost pricing;
};
typedef struct Node {
struct Data grocery_item;
struct Node *next;
} Node;

/* below are prototypes for all functions declared in this directory */
void read_file(Node **list_head, char *input);
int read_inv(FILE *input_file, Node **list_head);
void insert_node(Node **list_head, Node *newNodePtr);
float get_totalrev(Node *list_head);
float get_wholesalecost(Node *list_head);
float curr_investment(Node *list_head);
float total_profit(Node *list_head);
float total_sales(Node *list_head);
float average_profit(Node *list_head);
float printgroceries_instock(Node *list_head);
float printgroceries_outstock(Node *list_head);
float print_grocerydept(Node *list_head);
void get_deptname(char *dept);
float add_item(Node **list_head);
int add_node_data(Node *list_head, Node *newNodePtr);
float order_groceries(Node **list_head);
float delete_item(Node **list_head);
int find_node(Node *list_head, int stockNum);
void delete_node(Node **list_head, int stockNum);
int print_headers();
int print_grocheaders();
Node * find_groceryitem(Node *list_head, int stockNum);
void check_count(int count);
void check_grocerydept(Node *traversePtr, char *dept, int count);
int check_outstock(Node *traversePtr, int count);
void print_avgprof(float totProfit, int sales);
int check_instock(Node *traversePtr, int count);
void build_nodearr(Node *list_head, int *quantities, Node **node_ptrs, int numGroceries);
int build_quantityarr(Node *node_ptr, int quantity);
int show_purchases(int *quantities, Node **node_ptrs, int numGroceries);
void update_values(Node **node_ptrs, int *quantities, int numGroceries);
int get_numgroceries(int num);
int get_choice(int choice);
float choices(float (**fp_array1)(Node**), float (**fp_array2)(Node*), Node **list_head_ptr, Node *list_head, int choice);
void write_file(Node *list_head, char *output);
void free_memory(Node *list_head);
