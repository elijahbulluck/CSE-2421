/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE
   STRICTLY ADHERED TO THE TENURES OF THE
   OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* delete_item is mostly a function that was used to make the delete_node function less lines, but it takes the pointer
   to list_head as a parameter and asks for the stock number that the user wishes to delete. */
float delete_item(Node **list_head) {
	/* initialize stock number */
	int stockNum;
	/* Prompt the user to enter a stock number that they wish to delete */
	printf("Please enter the grocery item stock number that you wish to delete, followed by enter. ");
	scanf("%d", &stockNum);			/* get stock number from user input */
	/* We can now go into the delete item function with the stock number to delete */
        delete_node(list_head, stockNum);
        printf("\n");
	return(0);			/* does not matter what is returned here */
}
