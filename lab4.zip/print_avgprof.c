/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
 *    TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 *     */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
#include <locale.h>                                     /* needed for setlocale */
/* This method prints the average profit to stay under the 10 line limit. */
void print_avgprof(float totProfit, int sales) {
	/* Now we can divide the total profit of every node by the sales of every node to get the average profit */
        float avgProfit = 0.0;
	avgProfit = totProfit / sales;
        setlocale(LC_NUMERIC,"");                       /* for printing out money */
        printf("Average profit: $%'.2f\n", avgProfit);                    /* ' will add commas into the float, .2 will show 2 decimal places */
        printf("\n");
}
