/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */

int build_nodearr(Node *list_head, int *quantities, Node *node_ptrs, int numGroceries) {
	for (int i = 0; i < numGroceries; i++) {
                printf("Enter stock number %d: ", i + 1);
                scanf("%d", node_ptrs[i]->grocery_item.stockNumber);
                node_ptrs[i] = find_groceryitem(*list_head, node_ptrs[i]->grocery_item.stockNumber);
                while (node_ptrs[i] == NULL) {
                        printf("ERROR: This stock number does not exist.\n");
                        printf("Enter stock number %d: ", i + 1);
                	scanf("%d", node_ptrs[i]->grocery_item.stockNumber);
                	node_ptrs[i] = find_groceryitem(*list_head, node_ptrs[i]->grocery_item.stockNumber);
		}
                printf("%s ", node_ptrs[i]->grocery_item.item);
		quantities[i] = build_quantityarr(node_ptrs[i], quantities[i]);	
        }
	return(0);
}
