/* BY SUBMITTING THIS FILE TO CARMEN, I CERTFIY THAT I HAVE STRICTLY ADHERED
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* find_node takes the list_head and a stock number as a parameter and returns the node of the grocery item. */
Node * find_groceryitem(Node *list_head, int stockNum) {
        /* create a traversePtr to iterate through the list */
        Node *traversePtr = list_head;
        while (traversePtr != NULL) {
                /* if the stock number of the traversePtr is equal to the stock number entered by the user, we will return 1,
                   which will make the user enter another stock number */
                if (traversePtr->grocery_item.stockNumber == stockNum) {
                        return(traversePtr);
                }
                /* move onto the next node in the list */
                traversePtr = traversePtr->next;
        }
	/* return null if the stock number isn't found */
        return(NULL);
}
