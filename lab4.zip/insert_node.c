/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE 
   STRICTLY ADHERED TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The insert node function inserts a new node into the list according to its stock number. */
void insert_node(Node **list_head, Node *newNodePtr) {
	/* create a node pointer to traverse through the list */
	Node *traversePtr;
	/* If the list is empty or the new node's stock number is less than the front node's, add it to the front */
	if (*list_head == NULL || (*list_head)->grocery_item.stockNumber > newNodePtr->grocery_item.stockNumber) {
		/* make the next of the new pointer point to the old front */
        	newNodePtr->next = *list_head;
		/* set the front to the new node */
        	*list_head = newNodePtr;
	}
	else {
		/* if it is not at the front, traverse through the list with traversePtr */
		traversePtr = *list_head;
		/* while there is still a next in the list and the current node has a stock number less than the new node,
 		   we must keep iterating through the loop */
		while (traversePtr->next != NULL && traversePtr->next->grocery_item.stockNumber < newNodePtr->grocery_item.stockNumber) {
			traversePtr = traversePtr->next;
		}
		/* when the correct spot is found, set the new node's next equal to the current spot's next */	
		newNodePtr->next = traversePtr->next;
		/* set traversePtr->next to the new node */
		traversePtr->next = newNodePtr;
	}	
} 
