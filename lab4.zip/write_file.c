/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE
   STRICTLY ADHERED TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* Write file writes whatever is left at the end of the user's execution of the program into an output file similar to the input one */
void write_file(Node *list_head, char *output) {
        FILE *output_file;                      /* declaration of the output file */
        output_file = fopen(output, "w");                 /* this line opens the file, "w" means we want to write to the file */
        /* we also have to check if we were able to open the file */
        if (output_file == NULL) {
                printf("Error creating a file.");
                exit(1);                /* this will end the program */
        }
	/* traverse through the list and print the data for each node */
	Node *traversePtr = list_head;
	/* count for end print statement */
	int count = 0;
	while (traversePtr != NULL) {
		/* print every data item of the traversePtr to the output file like the input file was made */
 		fprintf(output_file, "%s\t%s\t%d\t%.2f\t%.2f\t%d\t%d\n", traversePtr->grocery_item.item, traversePtr->grocery_item.department,
		traversePtr->grocery_item.stockNumber, traversePtr->grocery_item.pricing.retailPrice, traversePtr->grocery_item.pricing.wholesalePrice, 
		traversePtr->grocery_item.pricing.retailQuantity, traversePtr->grocery_item.pricing.wholesaleQuantity);
		/* add to the count */
		count++;	
		/* advance the pointer */
		traversePtr = traversePtr->next;
	}	
        /* fclose() will then close the file while checking if fclose(output_file) != 0 and exit the program if it is */
        if(fclose(output_file) != 0) {
                printf("Error closing file.\n");
                exit(1);        /* this will end the program */
        }
        /* If the file successfully is printed into, this message will print to the screen */
        printf("A total of %d grocery item records were written to file %s\n", count, output);
	/* free the memory of each node */
	free_memory(list_head);
}
