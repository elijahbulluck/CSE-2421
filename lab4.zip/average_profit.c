/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>                                     
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The average_profit function takes the total profit (#4) divided by the total number of sales (#5). I could not get the 
 * function to work with both of the past functions in my implementation, but it was said that it was okay for another calculation
 * to be done in Piazza.
 */
float average_profit(Node *list_head) {
	/* create the node that will traverse through the linked list of the profit and sales totals */
        Node *traversePtr = list_head;
	/* Initialize the total profit and sales that will be used in the operation for average profit */
	float totProfit = 0.0;
	int sales = 0;
	/* loop through the linked list and add all of the profits and sales (I copy and pasted the code from the earlier 
 	   options) */
	while (traversePtr != NULL) {
		/* First total profit is calculated by total revenue - wholesale cost + cost of current inventory which are
 		   options #1, #2, and #3 respectively */
		totProfit += (traversePtr->grocery_item.pricing.retailPrice *
                traversePtr->grocery_item.pricing.retailQuantity) - (traversePtr->grocery_item.pricing.wholesalePrice *
                traversePtr->grocery_item.pricing.wholesaleQuantity) + (traversePtr->grocery_item.pricing.wholesalePrice *
                (traversePtr->grocery_item.pricing.wholesaleQuantity - traversePtr->grocery_item.pricing.retailQuantity));
		/* To calculate sales, we add up each items retail quantity */
                sales += traversePtr->grocery_item.pricing.retailQuantity;
		/* after getting all of the data for one node, move to the next one */
		traversePtr = traversePtr->next;	
	}
	print_avgprof(totProfit, sales);
	return(0);				/* nothing has to be returned here */
}
