/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the build_nodearr functions fills the node array with the appropriate nodes that we want to change. 
 * It also fills the quantities array. Went over the 10 line limit checking if a stock number existed or not, which was not required. */
void build_nodearr(Node *list_head, int *quantities, Node **node_ptrs, int numGroceries) {
	/* Create a loop that loops for the number of groceries entered by the user */
	for (int i = 0; i < numGroceries; i++) {
		/* stock number that will be checked to see if it is an actual number */
                int stockNum;
		printf("Enter stock number %d: ", i + 1);
		/* the user has been prompted to enter a stock number */
                scanf("%d", &stockNum);
		/* now we will go into a function that finds the node */
                node_ptrs[i] = find_groceryitem(list_head, stockNum);
		/* if the function doesn't find the node (returns null) we will prompt the user to enter a new number and check again */
                while (node_ptrs[i] == NULL) {
                        printf("ERROR: This stock number does not exist.\n");
			printf("Enter stock number %d: ", i + 1);
                	scanf("%d", &stockNum); 
			node_ptrs[i] = find_groceryitem(list_head, stockNum);		/* second check */                       
                }
		/* print the item the user wishes to purchases */
                printf("%s ", node_ptrs[i]->grocery_item.item);
		/* we now will call a function to fill the quantities array */
                quantities[i] = build_quantityarr(node_ptrs[i], quantities[i]);
        }
}
