/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the update_values function updates the values of the node quantites according to how many of the items were purchased */
void update_values(Node **node_ptrs, int *quantities, int numGroceries) {
	/* loop for number of stock numbers ordered (numGroceries) */
	for (int i = 0; i < numGroceries; i++) {
		/* add the quantity to retail to represent new sales */
		node_ptrs[i]->grocery_item.pricing.retailQuantity += quantities[i];
        }
}
