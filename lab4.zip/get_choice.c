/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>                                    
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* get_choice gets the choice of option from the user and returns it to be used in other functions */
int get_choice(int choice) {
	/* Create an array of strings for the options that we can loop through to write less code */
        char *choice_arr[17] = {"\n", "Please enter an integer between 1 and 13:\n", "1) Print Total Revenue\n",
	"2) Print Total Wholesale Cost\n", "3) Print Current Grocery Item Investment\n", "4) Print Current Profit\n",
	"5) Print Total Number of Grocery Items Sold\n", "6) Print Average Profit per Grocery Item\n", "7) Print Grocery Items In Stock\n",
	"8) Print Out of Stock Grocery Items\n", "9) Print Grocery Items for a Department\n", "10) Grocery List Purchase\n", 
	"11) Add Grocery Item to Inventory\n", "12) Delete Grocery Item from Inventory\n", "13) Exit Program\n", "Option: "};
	/* Loop through the choice array to print out all the options */
	for (int i = 0; i < 16; i++) {
		printf("%s", choice_arr[i]);
	}
	/* get the user's choice (we can assume that the user will enter a number 1 through 13) */
	scanf("%d", &choice);
	/* rturn the choice that the user entered */	  	
        return choice;
}

