/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The printgroceries_instock function prints the items that have an equal wholesale quantity to retail quantity. */
float printgroceries_outstock(Node *list_head) {
        printf("Grocery Items Out of Stock:\n");
        print_headers();
	/* create a traversePtr to go through the list */
        Node *traversePtr = list_head;
	int count = 0;
	 /* while there is still a node in the list and the requirements are fulfilled, print out all of the required things on the output sample */
        count = check_outstock(traversePtr, count);
	/* print a message if there are no out of stock items */
	if (count == 0) {
		printf("There are currently no Out of Stock Grocery Items\n");
	}
	/*not sure if printing a new line cunts toward the 10 line limit */
	printf("\n");
	return(0);
}
