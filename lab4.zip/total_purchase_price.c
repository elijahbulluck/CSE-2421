
void total_purchase_price(Node *node_ptrs, int *quantities, int numGroceries) {
	float totPrice = 0.0;
	for (int i = 0; i < numGroceries; i++) {
                printf("%-25d\t%-25d\t%-25s\t%-25s\t%-25.2f\n", node_ptrs[i]->grocery_item.stockNumber, quantities[i],
                node_ptrs[i]->grocery_item.department, node_ptrs[i]->grocery_item.item, (node_ptrs[i]->grocery_item.pricing.retailPrice * quantities[i]));
                totPrice = totPrice + (node_ptrs[i]->grocery_item.pricing.retailPrice * quantities[i]);
        }
        printf("\n");
        setlocale(LC_NUMERIC,"");
        printf("The total price for all items is: $%'.2f\n", totPrice);
}
