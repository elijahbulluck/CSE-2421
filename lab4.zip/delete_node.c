/* BY SUBMITTING THIS FILE TO CARMEN, I CERTFIY THAT I HAVE STRICTLY ADHERED
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
*/
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* delete_node takes a &list_head and a stock number as a parameter and removes the node with the stock number. */
void delete_node(Node **list_head, int stockNum) {
	/* declare a pointer to traverse the list */
	Node *traversePtr = *list_head;
	/* declare a node to maintain a pointer to the node before the node where we are */
	Node *priorNode;
	/* If the first item in the list has the same stock number, we must delete it */
        if (traversePtr != NULL && traversePtr->grocery_item.stockNumber == stockNum) {
		/* Set the next node in the linked list to the first node */
		*list_head = traversePtr->next;
		/* free the node we want to delete */
		free(traversePtr);
		/* Tell the user that the grocery item was deleted and exit the function */
		printf("Grocery item stock number %d was deleted.\n", stockNum);
		return;
	}
	/* now if it wasn't the first node, we need to loop through the entire list */
	while (traversePtr != NULL && traversePtr->grocery_item.stockNumber != stockNum) {
		/* maintain a pointer to the node before where we are */
		priorNode = traversePtr;
		/* advance in the list */
		traversePtr = traversePtr->next;	
	}
	/* If we reach the end without finding an equal stock number, we must tell the user that it was not found */
	if (traversePtr == NULL) {
		printf("ERROR: Grocery item stock number %d was not found on the list.", stockNum);
		return;
	}
	/* change the next pointer of priorNode */
	priorNode->next = traversePtr->next;
	/* free the node we want to delete and tell the user it was deleted */
	free(traversePtr);
	printf("Grocery item stock number %d was deleted.\n", stockNum);
}
