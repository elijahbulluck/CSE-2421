/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
#include <locale.h>                                     /* needed for setlocale */
/* total_profit is a function that calculates the total profit. This is the total revnue minus
 * total wholesale cost minus cost of inventory. totProfit is returned, but this is essentially a void method. */
float total_profit(Node *list_head) {
	/* create a pointer to traverse through the list */	
	Node *traversePtr = list_head;
	/* intialize total profit */
        float totProfit = 0.0;
	/* go through the linked list and calculate total profit */	
        while (traversePtr != NULL) {
		/* total profit is calculated from the last 3 options, so we can copy and paste each calculation from
 		   those functions to give us the calculation we need. Each option (1,2,3) that is needed for this calculation
		   is parenthesized. */
                totProfit += (traversePtr->grocery_item.pricing.retailPrice *
                traversePtr->grocery_item.pricing.retailQuantity) - (traversePtr->grocery_item.pricing.wholesalePrice *
                traversePtr->grocery_item.pricing.wholesaleQuantity) + (traversePtr->grocery_item.pricing.wholesalePrice *
                (traversePtr->grocery_item.pricing.wholesaleQuantity - traversePtr->grocery_item.pricing.retailQuantity));
		/* after getting all of the data for one node, move to the next one */	
                traversePtr = traversePtr->next;
        }
	/* Print out the total revenue using setlocale */
	setlocale(LC_NUMERIC,"");	
        printf("Total profit: $%'.2f\n", totProfit);				/* ' will add commas into the float, .2 will show 2 decimal places */
	printf("\n");
	return(totProfit);				/* nothing has to be returned here, but return the profit in case I would come back to it later */
}
