/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE
 *    STRICTLY ADHERED TO THE TENURES OF THE
 *    OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The read_inv function reads in the data for the nodes in the linked list and also counts and returns the amount of items. */
int read_inv(FILE *input_file, Node **list_head) {
	/* initialize count variable */
        int count = 0;
        while(1) {
                Node *newNodePtr = (Node*)malloc(sizeof(Node));                 /* alloc space for a new node */
                /*check for error */
                if (newNodePtr == NULL) {
                        printf("ERROR: The requested space cannot be allocated. Exiting the program.\n");
                        /* exit(1) will end the program */
                        exit(1);
                }
        /* read in the line and the data and if it is not the end of the file, store it in the linked list. */
                if (fscanf(input_file, "%[^\t]\t%[^\t]\t%d\t%f\t%f\t%d\t%d\n", newNodePtr->grocery_item.item, newNodePtr->grocery_item.department,
                &newNodePtr->grocery_item.stockNumber, &newNodePtr->grocery_item.pricing.retailPrice, &newNodePtr->grocery_item.pricing.wholesalePrice,
                &newNodePtr->grocery_item.pricing.retailQuantity, &newNodePtr->grocery_item.pricing.wholesaleQuantity) == EOF) {
                        free(newNodePtr);
                        break;
                }
                /* insert the new node into the linked list */
                insert_node(list_head, newNodePtr);
                /* add to the count that is printed out at the end of the reading */
                count++;
        }
	return(count);
} 
