Test	Item	447	1.23	4.56	32	100
Ben & Jerry's Pints - Cherry Garcia	Frozen Foods	550	3.29	2.51	400	400
Ben & Jerry's Pints - Half Baked	Frozen Foods	551	3.29	2.51	350	400
Nabisco OREO Cookies	Cookies	667	2.49	1.87	310	500
Nabisco OREO Mint Cream Cookies	Cookies	668	2.49	1.87	440	500
Nabisco OREO Double Stuf Cookies	Cookies	672	3.29	2.29	312	500
Ore-Ida Frozen Potatoes	Frozen Foods	780	4.69	1.64	270	500
Horizon Organic Milk - 64 fl oz	Dairy	962	3.29	2.01	527	800
Pillsbury Cinnamon Rolls	Dairy	1050	2.29	1.12	170	2000
Philadelphia Cream Cheese Brick	Dairy	1051	2.29	1.12	449	1000
Minute Maid Fruit Drinks - Orange	Refrigerated Items	1399	2.29	0.52	256	500
Tostito Chips - Original	Snacks	1850	2.99	1.75	60	500
Cheez-it	Snacks	1851	2.99	1.75	160	350
Bush's Seasoned Black Beans	Canned Goods	2120	1.29	0.77	420	1000
Campbell's Condensed Soup - Tomato	Canned Goods	2150	1.29	0.77	933	2000
Campbell's Condensed Soup - ChickNoodle	Canned Goods	2151	1.29	0.77	421	2000
Campbell's Condensed Soup - Veg Beef	Canned Goods	2152	1.29	0.77	577	2000
Campbell's Condensed Soup - Crm Mush	Canned Goods	2153	1.29	0.77	1250	2000
Me	Item	2250	2.13	2.34	32	232
Plochman Yellow Mustard	Dry Goods	2252	1.39	0.92	220	500
Minute Instant Rice	Dry Goods	3232	2.39	0.64	320	500
Vlasic Dill Pickles	Refrigerated Items	4001	2.29	1.57	159	300
Spare Ribs - Pork	Fresh Meat	7020	3.49	2.10	212	410
Ground Beef - 95%lean	Fresh Meat	8282	1.69	0.79	347	500
Fresh Tuna Steaks	Fresh Meat	9777	9.50	6.00	100	155
