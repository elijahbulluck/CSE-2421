/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the build_quantityarr function takes a pointer to the node and the quantity  entered by the user and gets the true quantity ordered */
int build_quantityarr(Node *node_ptr, int quantity) {
	printf("Enter the quantity: ");
        scanf("%d", &quantity);			/* user will enter quantity */
	/* if there is not enough to fullfill the order, set the quantity equal to the max number in stock */
        if (quantity > node_ptr->grocery_item.pricing.wholesaleQuantity - node_ptr->grocery_item.pricing.retailQuantity) {
        	printf("There are not enough quantities to fullfill this order. Order will have a quantity of %d\n", 
		node_ptr->grocery_item.pricing.wholesaleQuantity - node_ptr->grocery_item.pricing.retailQuantity);
              	quantity = node_ptr->grocery_item.pricing.wholesaleQuantity - node_ptr->grocery_item.pricing.retailQuantity;	/* quantity is now max number in stock */
        }
	return quantity;		/* return the quantity */

}
