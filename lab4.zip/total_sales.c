/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the total_sales function prints the sum of all of the retail quantities */
float total_sales(Node *list_head) {
	/* create a traversePtr to go through the list */
        Node *traversePtr = list_head;
	/* intialize sales */
        int sales = 0;
	/* go through the list and add the retail quantities to get the total number of sales */
        while (traversePtr != NULL) {
                sales += traversePtr->grocery_item.pricing.retailQuantity;		/* will give us total sales */
                traversePtr = traversePtr->next;
        }
        printf("Total number of grocery items sold: %d\n", sales);		/* Print the number of sales */
	printf("\n");
	return(0);		/* nothing has to be returned here */
}
