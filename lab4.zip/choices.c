/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>                                     /* needed for allocating memory */
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The choices function takes the function pointers, list head, list head pointer, and choice as parameters to 
   execute the option according to the users choice. */
float choices(float (**fp_array1)(Node**), float (**fp_array2)(Node*), Node **list_head_ptr, Node *list_head, int choice) {
		/* If the choice is less than 10, we can go through the second array that takes 
 		the list head as a parameter and executes the given option */
		if (choice < 10) {
			return	fp_array2[choice - 1](list_head);		/* choice - 1 to account for 0th position */
		}
		/* If it is anything else (10-13), we can go through the first array with the list head pointer as a parameter since
  		these methods involve changing the linked list */
		else {
			return fp_array1[choice - 10](list_head_ptr);		/* choice - 10 since the operations start at 10 */
		}
}
