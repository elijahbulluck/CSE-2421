/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE
   STRICTLY ADHERED TO THE TENURES OF THE
   OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>                                     /* needed for allocating memory */
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The add_item function is used to allocate space for the new grocery item being added and then calling the functions
   to add the data of the node and also add the node to the linked list. */
float add_item(Node **list_head) {
	/* allocate space for the new node */
	Node *newNodePtr = (Node*)malloc(sizeof(Node));
	/* check if the space can be allocated */
	if (newNodePtr == NULL) {
                printf("ERROR: The requested space cannot be allocated. Exiting the program.\n");
                /* exit(1) will end the program */
                exit(1);
        }
	/* the function add_node_data will add all of the values for grocery_item to the node, and then the node
           is inserted into the list with the function insert_node in the line after */
        add_node_data(*list_head, newNodePtr);
        insert_node(list_head, newNodePtr);
	/* Print and tell the user that the node has successfully been added */
	printf("Your item has been successfully added.\n");
	printf("\n");
	return(0);
}
