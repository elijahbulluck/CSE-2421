/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* get_deptname gets the name of the department that the user wants to print and prints it out. */
void get_deptname(char *dept) {
	/* prompt the user to enter a department name */
	printf("Enter department name to print: ");
        scanf(" %[^\n]", dept);
        printf("Grocery item list for %s:\n", dept);
        printf("\n");
	/* Print out the rows */
        print_headers();
}
