/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO THE 
   TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
*/

#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>                                     /* needed for allocating memory */
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the add_node_data function is used to prompt the user for all of the data inside of a new node. */
int add_node_data(Node *list_head, Node *newNodePtr) {
	/* The first thing the user is asked for is the grocery item name, including whitespace. Rather than
 	   storing all of the data in different strings, integers, and floats, I decided to directly input them into
	   their location in the node data.
 	 */
	printf("Enter grocery item name: ");
	scanf(" %50[^\n]", newNodePtr->grocery_item.item);
	/* Next is the department name, also including whitespace. */
	printf("Enter department: ");
	scanf(" %30[^\n]", newNodePtr->grocery_item.department);
	/* The user then must enter the stock number, which is an integer. */
	printf("Enter item stock number: ");
	/* initialize and get stock number from user input */
	scanf("%d", &newNodePtr->grocery_item.stockNumber);
	/* We will then call a function that checks if the stock number is already present in the linked list, 
           and if it is, it will loop until the user enters one that isn't taken */
	int i = find_node(list_head, newNodePtr->grocery_item.stockNumber);
	while (i == 1) {
		/* prompt the user to enter another stock number */
		printf("Enter item stock number: ");
		/* allow the user to re-enter the stock number */
        	scanf("%d", &newNodePtr->grocery_item.stockNumber);
		/* check if i is not equal to 1 again to determine if the loop will continue */
		i = find_node(list_head, newNodePtr->grocery_item.stockNumber);
	}
	/* The user must enter the retail and wholesale prices, which are both floats. */
	printf("Enter item retail price: ");
	scanf("%f", &newNodePtr->grocery_item.pricing.retailPrice);
	printf("Enter item wholesale price: ");
        scanf("%f", &newNodePtr->grocery_item.pricing.wholesalePrice);
	/* The user has to enter the retail and wholesale quantities, which are integers. */
	printf("Enter item retail quantity: " );
	scanf("%d", &newNodePtr->grocery_item.pricing.retailQuantity);
	printf("Enter item wholesale quantity: " );
        scanf("%d", &newNodePtr->grocery_item.pricing.wholesaleQuantity);
	return(0);	
}

