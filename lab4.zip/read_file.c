/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE
   STRICTLY ADHERED TO THE TENURES OF THE
   OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* read_file takes &list_head and the string for the input files as parameters and read the file into the linked list. */
void read_file(Node **list_head, char *input) {
	/* open the file and check for an error if it does not open */
	FILE *input_file = fopen(input, "r");
	if (input_file == NULL) { 
		printf("No file found");
		exit(1);
	}
	printf("Reading inventory from file %s\n", input); 
       	/* initialize count variable */
	int count = 0;
	count = read_inv(input_file, list_head);	/* read in items with read_inv function */
	/* tell the user how many items were read in */
	printf("A total of %d items were read into inventory from the file %s\n", count, input);
	/* check for errors in closing the file */
	if (fclose(input_file) != 0) {
                printf("fclose failed\n");
                exit(1);
        }
}
