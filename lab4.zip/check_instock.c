/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* this function was made to meet the 10 line limit in printgroceries_instock. Prints the in stock items */
int check_instock(Node *traversePtr, int count) {
	/* while there is still a node in the list and the requirements are fulfilled, print out all of the required things on the output sample */
        while (traversePtr != NULL) {
                /* print out the current stock and item if the wholesale quanitty is greater than the retail quantity */
                if (traversePtr->grocery_item.pricing.wholesaleQuantity - traversePtr->grocery_item.pricing.retailQuantity > 0) {
                        printf("%-25d\t%-25d\t%-25s\t%-25s\n", traversePtr->grocery_item.stockNumber,
                        (traversePtr->grocery_item.pricing.wholesaleQuantity - traversePtr->grocery_item.pricing.retailQuantity),
                        traversePtr->grocery_item.department, traversePtr->grocery_item.item);
                        count++;
                }
                /* advance to the next node */
                traversePtr = traversePtr->next;
        }
	return(count);
}
