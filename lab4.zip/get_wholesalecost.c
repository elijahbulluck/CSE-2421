/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
#include <locale.h>                                     /* needed for setlocale */
/* get_wholesale cost prints out the sums of the wholesale cost * wholesale quantity for each item. */
float get_wholesalecost(Node *list_head) {
	/* create a traversePtr to go through the lsit */
	Node *traversePtr = list_head;
	/* initialize the cost */
        float cost = 0.0;
        while (traversePtr != NULL) {
		/*multiply the wholesale price by the wholesale quantity and add it to the total cost */
                cost += traversePtr->grocery_item.pricing.wholesalePrice *
                traversePtr->grocery_item.pricing.wholesaleQuantity;
		/* move to the next node */
                traversePtr = traversePtr->next;
        }
	setlocale(LC_NUMERIC,"");		/* for printing money */
        printf("Total wholesale cost: $%'.2f\n", cost);			/* ' will add commas into the float, .2 will show 2 decimal places */
	printf("\n");
	return(cost);			/* nothing has to be returned here, I just chose to return the cost */
}
