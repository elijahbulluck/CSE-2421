/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The printgroceries_instock function prints the items that have a higher wholesale quantity than retail quantity. */
float printgroceries_instock(Node *list_head) {
	printf("Grocery items in Stock:\n");
	print_headers();
	/* create a traversePtr to go through the list */
	Node *traversePtr = list_head;
	/* create a count to see if any items are actually in stock */
	int count = 0;
	/* while there is still a node in the list and the requirements are fulfilled, print out all of the required things on the output sample */
	count = check_instock(traversePtr, count);
	check_count(count);
	printf("\n");
	return(0);
}
