/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#define _GNU_SOURCE                     /* for strcasestr() */
#include <stdio.h>                      /* needed for IO library prototypes */
#include <stdlib.h>
#include <string.h>                     /* for strcasestr() */
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* this method was implemented to meet the 10 line limit in print_grocerydept. Prints the specified dept items */
void check_grocerydept(Node *traversePtr, char *dept, int count) {
	while (traversePtr != NULL) {
                /* compare the substring to the department name ignoring case */
                if (strcasestr(traversePtr->grocery_item.department, dept) != NULL) {
                        /* if the substring is found, print the information to the screen */
                        printf("%-25d\t%-25d\t%-25s\t%-25s\n", traversePtr->grocery_item.stockNumber,
                        (traversePtr->grocery_item.pricing.wholesaleQuantity - traversePtr->grocery_item.pricing.retailQuantity),
                        traversePtr->grocery_item.department, traversePtr->grocery_item.item);
                        /* add to the count so the message below is not printed */
                        count++;
                }
                /* advance through the list */
                traversePtr = traversePtr->next;
        }
        /* if no items were found, print that no items were found and exit the program */
        if (count == 0) {
                printf("No items were found in %s.\n", dept);
        }
}
