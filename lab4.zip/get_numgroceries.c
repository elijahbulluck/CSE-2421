/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the get_numgroceries functions returns the number of groceries the user wishes to order */
int get_numgroceries(int num) {
        printf("How many items do you wish to order? ");
        scanf("%d", &num);		/* this will be the number of groceries the user wants to order */
	return num;			/* return the number of groceries */
}
