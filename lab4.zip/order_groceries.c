/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the order_groceries function is for the extra credit option 10 opportunity. It calls functions that ask the user how many items they want to
 * order, their quantities, and then prints and updates the quantities in the linked list. */
float order_groceries(Node **list_head) {
	int numGroceries = get_numgroceries(numGroceries);		/* function to get number of groceries */
	int quantities[numGroceries + 1];			/* array of the quantities being ordered */
	Node *node_ptrs[numGroceries + 1];			/* array of the nodes being changed */
	build_nodearr(*(list_head), quantities, node_ptrs, numGroceries);		/* this function builds the array full of the nodes we want */
	show_purchases(quantities, node_ptrs, numGroceries);		/* this function prints the purchases of the user */
	update_values(node_ptrs, quantities, numGroceries);		/* this function updates the values of the retail and wholesale quantities */
	return(0);
}
