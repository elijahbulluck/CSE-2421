/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>
#include <stdlib.h>
#include "lab4.h"
/* print_grocerydept takes a department name or department name substring and prints out the info for the specific department. */
float print_grocerydept(Node *list_head) {
        /* initialize the department name (max is 30 characters in struct */
	char dept[30];
	/* get the substring from the get_deptname function */ 
	get_deptname(dept);
	/* initialize count to print message if no items are found */
	int count = 0;
	/* create a traversePtr to go through the list */
        Node *traversePtr = list_head;
        check_grocerydept(traversePtr, dept, count);
	return(0);
}
