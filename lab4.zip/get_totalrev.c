/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
#include <locale.h>                                     /* needed for setlocale */
/* get_totalrev takes the list head as a parameters and iterates through the linked list adding each nodes retail
   price multiplied by the retail quantity. */
float get_totalrev(Node *list_head) {
	/* create a pointer to traverse through the list */
	Node *traversePtr = list_head;
	/* Initialize the total revenue */
	float rev = 0.0;
	/* go through the linked list and multiply the retail price * retail quantity */
        while (traversePtr != NULL) {
		/* multiply retail price * retail quantity and add to the total */
		rev += traversePtr->grocery_item.pricing.retailPrice * 
		traversePtr->grocery_item.pricing.retailQuantity;		
		/* go to the next node in the list, if it is null, the loop will end */
                traversePtr = traversePtr->next;
	}
	/* Print out the total revenue using setlocale */
	setlocale(LC_NUMERIC,"");
	printf("Total revenue: $%'.2f\n", rev);
	printf("\n");
	return(rev);		/* return the total revenue, though it does not matter that is returned here since the value isnt saved */
}
