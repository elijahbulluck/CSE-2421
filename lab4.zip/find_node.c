/* BY SUBMITTING THIS FILE TO CARMEN, I CERTFIY THAT I HAVE STRICTLY ADHERED
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* find_node takes the list_head and a stock number as a parameter and returns if the stock number is already entered or not. */
int find_node(Node *list_head, int stockNum) {
	/* create a traversePtr to iterate through the list */
	/* if the stock number is not an option, tell the user to enter one that is */
	if (stockNum < 1 || stockNum > 10000) {
		printf("Please enter a stock number between 1 and 10000.\n");
		/* return 1 since the number needs to be re-entered */
		return(1);
	}
	Node *traversePtr = list_head;
	while (traversePtr != NULL) {
		/* if the stock number of the traversePtr is equal to the stock number entered by the user, we will return 1,
 		which will make the user enter another stock number */
		if (traversePtr->grocery_item.stockNumber == stockNum) {
			/* tell the user that the stock number is in use */
			printf("This stock number is already in use.\n");
			return(1);
		}
		/* move onto the next node in the list */
		traversePtr = traversePtr->next;
	}
	
	/* Return 0 if the stock number is not found */
	return(0);
}

