/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO 
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
#include <locale.h>                                     /* needed for setlocale */
/* the show_purchases method prints out the purchases of the user with the correct quantity */
int show_purchases(int *quantities, Node **node_ptrs, int numGroceries) {
	printf("You purchased: \n");
	float totPrice = 0.0;
	/* print the headers for the rows */
        print_grocheaders();
	/* create a loop for all of the purchases (numGroceries) */
        for (int i = 0; i < numGroceries; i++) {
		/* multiply the price by the quantity to get the price of each item */
                printf("%-25d\t%-25d\t%-25s\t%-25s\t%-25.2f\n", node_ptrs[i]->grocery_item.stockNumber, quantities[i],
                        node_ptrs[i]->grocery_item.department, node_ptrs[i]->grocery_item.item, (node_ptrs[i]->grocery_item.pricing.retailPrice * quantities[i]));
                /* add the prices together to get the total cost to print out */
		totPrice = totPrice + (node_ptrs[i]->grocery_item.pricing.retailPrice * quantities[i]);
        }
	setlocale(LC_NUMERIC,"");                       /* for printing out money */
	printf("\n");
        printf("Total cost for all items is: $%'.2f\n", totPrice);                    /* ' will add commas into the float, .2 will show 2 decimal places */
	return(0);
}
