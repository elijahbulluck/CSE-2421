/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
 *  *    TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 *   *     */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The print_headers function prints the headers for the grocery list neatly */
int print_grocheaders() {
        /* intialize an array of the titles of the headers */
        char *headers[6] = {"Stock#", "Quantity", "Department", "Item", "Price"}; 
        for (int i = 0; i < 5; i++) {
                /* print them with justification to the right */
                printf("%-32s", headers[i]);
        }
        printf("\n");
        return(0);              /* end program */
}

