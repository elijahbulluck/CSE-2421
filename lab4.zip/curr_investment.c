/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
#include <locale.h>                                     /* needed for setlocale */
/* curr_investment takes the list head as a parameters and prints out the current investment in grocery items. */
float curr_investment(Node *list_head) {
	/* create the node that will traverse through the linked list of the wholesale price and quantity
           as well as retail quantity. */	
	Node *traversePtr = list_head;
	/* initialize the final value of the current investment */
        float currInv = 0.0;
	/* loop through the linked list and add all of the current investments for each node */
        while (traversePtr != NULL) {
		/* curr investment is calculated by the sum of wholesale price * (wholesale quantity - retail quantity)
 		do these calculations for each node and loop through the linked list, adding each to the sum */
                currInv += traversePtr->grocery_item.pricing.wholesalePrice *
                (traversePtr->grocery_item.pricing.wholesaleQuantity - traversePtr->grocery_item.pricing.retailQuantity);
		/* after getting all of the data for one node, move to the next one */
                traversePtr = traversePtr->next;
        }
	setlocale(LC_NUMERIC,"");			/* for printing out money */
        printf("Total wholesale investment: $%'.2f\n", currInv);	/* ' will add commas into the float, .2 will show 2 decimal places */
	printf("\n");
	return(currInv);			/* nothing has to be returned here, just returned currInv for convenience */
}
