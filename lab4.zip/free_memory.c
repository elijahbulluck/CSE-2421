/* BY SUBMITTING THIS FILE TO CARMEN, I CERTFIY THAT I HAVE STRICTLY ADHERED
   TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* the free_memory function frees all of the nodes that space was allocated for to prevent a memory leak */
void free_memory(Node *list_head) {
	/* create a traversePtr to go through the list */
	Node *traversePtr = list_head;
	while (traversePtr != NULL) {
		/* create a new node to move to after traversePtr is freed */
		Node *next = traversePtr->next;
		/* free the current node */
		free(traversePtr);
		/* move to the next node */
		traversePtr = next;
	}
}
