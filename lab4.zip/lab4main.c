/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
 * TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
 *
 * Student name: Elijah Bulluck
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>
#include "lab4.h"                                       /* an include file in the lab4 directory */
/* The main method for lab4. Takes 3 arguments from the command line */
int main(int argc, char *argv[]) {
	/* If there are not 3 command line arguments, print a usage message and exit the program with failure. */
	if (argc != 3) {
		printf("USAGE: %s <input_file> <output_file>\n", argv[0]);
		exit(1);
	}
	/* initialize the list head to null */
	Node *list_head = NULL;
	/* Read the input file argv[1] and create the linked list in list_head */
	read_file(&list_head, argv[1]);
	/* create two function point arrays, one for passing in &list_head as a parameter and one for passing in
 	   list_head as a parameter */
	float (*fp_array1[4])(Node**) = {order_groceries, add_item, delete_item};   
	float (*fp_array2[10])(Node*) = {get_totalrev, get_wholesalecost, 
	curr_investment, total_profit, total_sales, average_profit, 
	printgroceries_instock, printgroceries_outstock, print_grocerydept};
	/* get the choice from the user which will tell us what function to execute */
	int choice = get_choice(choice);
	/* loop the choices function until the user enters 13 to exit the program */
	while (choice != 13) {
	/* eneter the choices method and execute the correct option */
	choices(fp_array1, fp_array2, &list_head, list_head, choice);
	/* ask the user for their choice again to see if the loop will continue or not */
	choice = get_choice(choice);
	}
	/* write to the output file that was the third argument passed in */
	write_file(list_head, argv[2]); 
	return(0);
}
