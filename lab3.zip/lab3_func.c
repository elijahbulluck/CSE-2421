/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY WITH
   RESPECT TO THIS ASSIGNMENT.
  
   Student Name: Elijah Bulluck
 */
#include <stdio.h>                                      /* needed for IO library prototypes */
#include <stdlib.h>                                     /* needed for allocating memory */
#include "lab3.h"					/* an include file in the lab3 directory */

/* The first function used is get_numquotes, which returns the number of quotes that the user is going to enter.
   the minimum amount of quotes is 1.
 */
int get_numquotes(void) {
	int num;			/* this is the number of quotes that will be returned */
	printf("How many quotes do you plan to enter? ");
        scanf("%d", &num);		/* get number of quotes from user input */
        /* if the user enters a number less than one, loop until the user enters a number greater than 1 */
	while (num < 1) {
                printf("Must enter a value greater than or equal to 1.\n");
                printf("How many quotes do you plan to enter? ");
                scanf("%d", &num);		/* now the user will enter another number */
        }
        return(num);			/* returns the value of the number of quotes */
}

/* The print_quotes function takes quotes and numQuotes as parameters and prints each quote on a newline with their number next to it. */
void print_quotes(char **quotes, int numQuotes) {
	printf("You've entered: \n");
	/* will loop for the number of quotes in the array */
	for (int i = 0; i < numQuotes; i++) {
		/* Use i + 1 for the number next to the quotes since the array starts at index 0 */
		printf("%d. %s\n", (i + 1), quotes[i]);
	}
	printf("\n");
}

/* The get_numfavorites function returns the number of quotes that the user wants to have saved to their favorites list. */ 
int get_numfavorites(int numQuotes) {
	int fav;			/* declaration of the number of favorites */
        printf("Of those %d quotes, how many do you plan to put on your favorites list? ", numQuotes);
        scanf("%d", &fav);
	/* loop if the number of favorites is greater than the number of quotes or equal to 0, since that is not possible */
	while (fav > numQuotes && fav <= 0) {
		printf("You must enter a number between 1 and %d.\n", numQuotes);
		printf("Of those %d quotes, how many do you plan to put on your favorites list? ", numQuotes);
       		scanf("%d", &fav);		/* this will be the new amount of favorites */
	}
	return(fav);			/* returns the number of favorites that the user entered. */
}

/* The print_favorites function takes favorites and the number of favorites as parameters and prints each favorite
   on a newline with their number next to it.
*/
void print_favorites(char ***favorites, int numFavorites) {
	printf("The quotes on your favorites list are:\n");
	for (int i = 0; i < numFavorites; i++) {
		/* we can print out the favorite using *favorites[i], since favorites is a pointer to the pointer of quotes */
		printf("%d. %s\n", (i + 1), *favorites[i]);
	}
	printf("\n");
}	

/* The get_save function asks the user for their choice of saving the file or not. If 1 is entered,
   the save file function will be entered and if 2 is entered, the program will end.
*/
int get_choice(void) {
	/* ask user for input and loop if they do not enter 1 or 2 */
        int choice;
	printf("Do you want to save them? (1=yes, 2=no): ");		/* ask the user if they would like to save the quotes to a file */
	scanf("%d", &choice);
        while (choice != 1 && choice != 2) {
                printf("Please enter 1 or 2.\n"); 	/* Tell the user that they have entered an invalid value and make them re-enter it. */
                printf("Do you want to save them? (1=yes, 2=no): ");
                scanf("%d", &choice);
        }
	return(choice);				/* returns the choice that the user enetered */
}

/* This function takes the users choice and acts upon it. If the user entered 1, it enters the save_file function. If not,
   the program ends.
*/
void save_or_exit(int choice, char **quotes, int numQuotes, char ***favorites, int numFavorites) {
	/* if the user wants to save the file, (enters 1) enter the save file function to save the file */
        if (choice == 1) {
                save_file(quotes, numQuotes, favorites, numFavorites);
        }
	/* if the user entered 2, exit the program successfully (with 0) */
	else {
		printf("Your quotes will not be saved to a file. Exiting the program.\n");
		/* the program will now go back to main and free the memory */
	}
}

/* The print_quotesfile function takes a file, quotes and numQuotes as parameters and prints each quote
   in the file on a newline. This is similar to the earlier print_quotes function, but inside of a file.
 */
void print_quotesfile(FILE *file,char **quotes, int numQuotes) {
	/* we have to use fprintf() to print inside of the file */
        fprintf(file, "Inspring Quotes:\n");
        /* will loop for the number of quotes in the array */
        for (int i = 0; i < numQuotes; i++) {
                /* Use i + 1 for the number next to the quotes since the array starts at index 0 */
                fprintf(file, "%s\n", quotes[i]);
        }
	fprintf(file, "\n");
}

/* The print_favoritesfile function takes a file, favorites and numFavorites as parameters and prints each favorite
   in the file on a newline. This is similar to the earlier print_favorites function, but inside of a file.
 */
void print_favoritesfile(FILE *file,char ***favorites, int numFavorites) {
	/* We have to use fprintf() to print inside the file */
	fprintf(file, "My favorites are:\n");
        /* will loop for the number of favorites in the array */
	for (int j = 0; j < numFavorites; j++) {
                /* *favorites[j] holds the address for the quote that was added to the favorites array */
                fprintf(file, "%s\n", *favorites[j]);				
        }
        fprintf(file, "\n");
}

