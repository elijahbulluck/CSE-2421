/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
   THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY WITH
   RESPECT TO THIS ASSIGNMENT.
 */

/* This file is used to hold all protoypes for the functions that I created. 
   The lines following this are all of them in one file, in the order that they are accessed in main.
*/
int get_numquotes(void);

void get_quotes(char **quotes, int numQuotes);

void print_quotes(char **quotes, int numQuotes);

int get_numfavorites(int numQuotes);

void get_favorites(char **quotes, int numQuotes, int numFavorites, char ***favorites);

void print_favorites(char ***favorites, int numFavorites);

int get_choice(void);

void save_or_exit(int choice, char **quotes, int numQuotes, char ***favorites, int numFavorites);

void save_file(char **quotes, int numQuotes, char ***favorites, int numFavorites);

void print_quotesfile(FILE *file,char **quotes, int numQuotes);

void print_favoritesfile(FILE *file,char ***favorites, int numFavorites);

void free_memory(char **quotes, int numQuotes, char ***favorites);
