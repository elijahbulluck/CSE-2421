/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO
 * THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY WITH
 * RESPECT TO THIS ASSIGNMENT.
 *
 * Student Name: Elijah Bulluck
 */
#include <stdio.h>					/* needed for IO library prototypes */
#include <stdlib.h>					/* needed for allocating memory */
#include "lab3.h"                                	/* an include file in the lab3 directory */
#include <string.h>					/* using for the method strcpy() in the get_quotes function */

/* The get quotes function copies each line of quotes that is entered in by the user into the quotes pointer array.
   Space for each quote is also allocated since we do not know how long the quote will be, but has a max of 300 characters. */
void get_quotes(char **quotes, int numQuotes) {
        /* the maximum length a quote can be is 300 characters, plus the null character */
        char line[301];
        printf("Enter the %d quotes, one to a line: ", numQuotes);
        /* the user will enter all of the quotes and seperate them all with newlines. Each line will 
           be read in and copied to the quotes array. */
        for (int i = 0; i < numQuotes; i++) {
                scanf(" %[^\n]", line);                         /* scans entire line */
                quotes[i] = (char*)malloc((301) * sizeof(char));               /* allocate the space for a max length (301) string in the quotes array */
                /* if we cannot allocate the space for the quotes, we should print an error message and exit with failure */
                if (quotes[i] == 0) {
                        printf("ERROR: The requested space cannot be allocated. Exiting the program.\n");
                        /* exit(1) will end the program */
                        exit(1);
                }
		strcpy(quotes[i], line);			/* used to copy the line read from user input into the quotes array */
        }
	printf("\n");
	print_quotes(quotes, numQuotes);        /* calls function in lab3_func.c that prints the quotes */
}

/* The get_favorites function takes the quotes and fills a pointer to those quotes with the chosen favorites by the user.
   We have to allocate space for the amount of favorites in the favorites array.
 */
void get_favorites(char **quotes, int numQuotes, int numFavorites, char ***favorites) {
	printf("Enter the number next to each quote you want on your favorites list: ");
	/* Use a loop to get all of the numbers that the user entered as favorites */
	for (int i = 0; i < numFavorites; i++) {
		int index;
		scanf("%d", &index); 
		/* we can set each index in the favorites array to point to the same address as the wanted quote */
		favorites[i] = &quotes[index - 1];		/* index - 1 because index starts at 0 */
	}
	printf("\n");
	print_favorites(favorites, numFavorites);                       /* calls function to print the favorites back to the output */
}

/* The save_file function prints all of the quotes and favorites to a file specified by the user. */
void save_file(char **quotes, int numQuotes, char ***favorites, int numFavorites) {
        /* make a string for the name of the file, the max can be 255 characters (+ null character) */
        char name[256];
        FILE *output_file;                      /* declaration of the output file */
        printf("What file name do you want to use? ");
        scanf("%s", name); /* this will give us the name of the file entered by the user */
        output_file = fopen(name, "w");                 /* this line opens the file, "w" means we want to write to the file */
        /* we also have to check if we were able to open the file */
        if (output_file == NULL) {
                printf("Error creating a file.");
                exit(1);                /* this will end the program */
        }
	/* call the functions to print the quotes and favorites into the output file */
	print_quotesfile(output_file, quotes, numQuotes);
	print_favoritesfile(output_file, favorites, numFavorites);
        /* fclose() will then close the file while checking if fclose(output_file) != 0 and exit the program if it is */
        if(fclose(output_file) != 0) {
                printf("Error closing file.\n");
                exit(1);        /* this will end the program */
        }
        /* If the file successfully is printed into, this message will print to the screen */
        printf("Your quotes list and favorites have been saved to the file %s\n", name);
}


/* free_memory function releases the storage in which all of the pointers point to back to the OS. */
void free_memory(char **quotes, int numQuotes, char ***favorites) {
        /* First, we can free all of the storage allocated for each quote array element by using a loop */
        for (int i = 0; i < numQuotes; i++) {
                free(quotes[i]);                /* frees the specified element in the array */
        	quotes[i] = NULL;               /* they should each be set to NULL so we do not unintentionally access them again */
        }
        /* Finally, we should free the space we allocated to fit all of the quotes in the character arrays quotes and favorites,
           and set them to NULL so we do not access them.
         */
        free(quotes);
        free(favorites);
        quotes = NULL;  
        favorites = NULL;
}

/* The main function where execution of the program begins. The functions above will be called on in this function, as well as the functions in
   lab3_func.c. All space will also be allocated in this function, except for the specific quotes.
*/
int main (void) {
	char **quotes;					/* will contain all of the quotes */
	char ***favorites;				/* will contain all of the favorites quotes */
	int numQuotes = get_numquotes();		/* calls function to get the number of quotes so we can allocate memory for them on the next line */
	quotes = (char**)malloc (numQuotes * sizeof(char*));
	/* if we cannot allocate the space for the quotes, we should print an error message and exit with failure */
        if (quotes == 0) {
                printf("ERROR: The requested space cannot be allocated. Exiting the program.\n");
                /* exit(1) will end the program */
                exit(1);
        }
	get_quotes(quotes, numQuotes);		/* calls function that stores the quotes in char **quotes */				
	int numFavorites = get_numfavorites(numQuotes);				/* calls function in lab3_func.c that gets the number of favorites */
	/* we must allocate the proper space (numFavorites) * sizeof(char**) for the favorites pointer */
        favorites = (char***)malloc((numFavorites) * sizeof(char**));
	/* check if the pointer returned was NULL and if it was, exit the program */
	if (favorites == 0) {
        	printf("ERROR: The requested space cannot be allocated. Exiting the program.\n");
                /* exit(1) will end the program */
                exit(1);
        }
	/* now we can call the get_favorites function in lab3_func.c */
	get_favorites(quotes, numQuotes, numFavorites, favorites);
	/* now we will go into the get_choice and save_or_exit function and see if the user wants to save the quotes or not */
	int choice = get_choice();
	save_or_exit(choice, quotes, numQuotes, favorites, numFavorites);
	/* regardless if the user wants to save the file or not, we must free the memory to prevent other errors */
	free_memory(quotes, numQuotes, favorites);
	return(0);		
}

