/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY
 WITH RESPECT TO THIS ASSIGNMENT.

 Student name: Elijah Bulluck
*/
#include <stdio.h>			/* copies IO library prototypes */

/* The method below, create_key, takes a blank 8-bit key as a paramater and returns the same key with 
 what the user input. The user input (4 bits) is represented as an 8 bit key by duplicating the user input. */

unsigned char create_key(char key) {
	int code;	/* the int that will be used for getchar() */
	/* create a loop that will collect each individual character of the 4 digit key */
        while ((code = getchar()) != '\n') {
		/* we must shift the key left 1 so it saves our character, and then use OR to plug in the next 0
 		or 1. Subtracting 48 because the decimal number for 0 and 1 are 48 and 49, so I will either get
 		0 or 1 after subtracting */
                key = (key << 1) | (code - 48);
        }
	/* I now have to shift the key left 4 and use OR so the 4 digit key will be duplicated across 8 digits */
        key = (key << 4) | key;
	return key;		/* returns new key */
}

/* rotate_left takes an unsigned 8-bit char (was having issues doing this with a signed char, as well as with the key)
   and rotates it 1 position to the left. Whatever was pushed off of the left in its shift of 1 is 
   restored at the least significant bit */

unsigned char rotate_left(unsigned char odd_char) {
	/* to get the most signficant bit, use AND operator on the char shifted right 7 to compare it to 8-bit 1.
 	This will make the char all 0's or make the far-right bit 1, since we shifted all of the earlier bits off. */ 
	char msb = (odd_char >> 7) & 0x01;
	/* now we can save the key with it shifted to the left 1, also being compared to the most-signficant bit
 	using operand OR. This will fill the least significant bit with the for most significant bit. */
        odd_char = (odd_char << 1) | msb;
	return odd_char;		/* returns new char */
}
/* rotate_right takes an unsigned 8-bit char and rotates it 1 position to the right. Whatever was pushed off of the
 right in its shift of 1 is restored at the most significant bit */
unsigned char rotate_right(unsigned char even_char) {
	/* to get the least signficant bit, use AND operator on the char shifted left 7 to compare it to 8-bit 1.
        This will make the char all 0's or make the far-left bit 1, since we shifted all of the later bits off. */
	char lsb = (even_char) & 0x01;
 /* now we can save the key with it shifted to the right 1, also being compared to the least-signficant bit
 *         using operand OR. This will fill the most significant bit with the for least significant bit. */
	even_char = (even_char >> 1) | (lsb << 7);	
 	return even_char;		/* returns new char */
}

/* This is the main method where the execution point begins. I did have another method that printed out
   a given string in rows, but it made it a lot easier for me to read when I deleted it */

int main(void) {
	/* Student name: Elijah Bulluck
 	The problem is that we have to recieve a string from user input, and decode it by using xOR and rotating it according to
	its position in the string. What I want to do is get the user input, print it out and also print its original hexidecimal values,
	then take the string and use xOR and rotate it accordingly. After that I will print out the new hexidecimal values and exit the program.
	*/
	/* All of these variables were declared in the place they were first used at first, but I had to
	move them all to the top so they were in scope for the #ifdef. I will explain where they are all used */

	int code;		/* int that is used to recieve code for getchar() */

	/* Next, I declared a string of characters that would be used to hold the user input. The max string
        can be 200 characters, so I used that as the capacity, and added 1 for the null character. */
	unsigned char char_string[201];
	int text_len = 0;		/* used to determine the length of the user input of characters. */
	int i = 0;		/* used in loop for printing the encoded hex values */
	int rowCount = 0;		/* used in a loop that counts the current number of hex values in a row */
	unsigned char key = 0x00;		/* default key with no user input */
	int num = 0;		/* also used in a loop to count hex values in a row, couldn't use same variable */

/* Added #ifdef PROMPT for part 3 in bit_encode2. I made it in an if-else way so if it didn't have PROMPT,
   It would do the normal process of printing out and asking for the user input. */
#ifdef PROMPT
	/* this first while loop will read in each char from the file and add it to char_string */
        while ((code = getchar()) != '\n') {
                char_string[text_len++] = (unsigned char)code;
        }
        char_string[text_len] = '\0';		/* adds the null character to the end */
	key = create_key(key);		/* creates a key with the next line of file */
        
	 /* this while loop uses XOR on the current character and rotates the bits left or right 
	 depending on their position in the string. the modulus operator is used to determine if they are in an odd or even position. */
	 while (num < text_len) {
		/* first step of the encode was to XOR every character with the key */ 
                char_string[num] = char_string[num] ^ key;
                /* If the char is in an odd position, (1,3,5,7 in the string) rotate it left 1. */
	        if (num % 2 == 0) {
                        char_string[num] = rotate_left(char_string[num]);
                }
		/* If the char is in an even position, (2,4,6,8 in the string) rotate it right 1. */
                else {
                        char_string[num] = rotate_right(char_string[num]);
                }
        num++;		/* loop until we reach the null character */
        }
	
	/* This for loop will print out every character with a space after, ignoring rows like part 3 talked about. It will 
 	loop through the length of the string and print out the decoded values, disregarding rows. After this is executed,
	the program will end, since the rest of the code is in the else body. */
	for (int s = 0; s < text_len; s++) {
		printf("%02X ", char_string[s]);
	}
	printf("\n");

/* This is the else body, which is used for bit_encode1. The ifdef was skipped if PROMPT was not declared in the Makefile. */
#else
	printf("enter cleartext: ");		/* ask the user to enter a string */
	/* while loop will fill the char array with user input. */
	while ((code = getchar()) != '\n') {
		char_string[text_len++] = (unsigned char)code;
	}	
	char_string[text_len] = '\0';		/* add null character to the end of the user input */
	printf("%s\n", char_string);		/* shows the user what they entered */
	printf("hex encoding:\n");
	/* This while loop counts the number of vaues it has printed out, and when it reaches 10, it starts a new row. */
	while (i < text_len) {
		/* if 10 values have been printed out on one line, make a new line and reset the number on the row. */
		if (rowCount == 10) {
			printf("\n");
			rowCount = 0;
		}
		printf("%02X ", char_string[i]);
		/* add to the row count and number of characters printed out to continue the loop */
		rowCount++;
		i++;
	}
	printf("\n");
	printf("\n");
	printf("Enter 4-bit key: ");		/* Asks the user to enter a key */
	key = create_key(key);		/* calls the key method to create the key from user input */
	/* This loop is the exact same from the if block. It rotates the characters according to their position in the string. */
	while (num < text_len) {
		char_string[num] = char_string[num] ^ key;
		if (num % 2 == 0) {
			char_string[num] = rotate_left(char_string[num]);
		}
		else {
			char_string[num] = rotate_right(char_string[num]);
		}
	num++;
	}
	/* now we must print the decoded characters. I will use the same loop that I used earlier for printing out the encoded
 	values to print out the decoded values, jsut with different variables, because the other variables have already been used. */
	printf("hex cyphertext:\n");
	int v = 0;		/* new count of total chars printed */
	int newc = 0;		/* new count of total chars printed on a certain row */
        while (v < text_len) {
                if (newc  == 10) {
                        printf("\n");
                        newc  = 0;
                }
                printf("%02X ", char_string[v]);
                newc++;
                v++;
	}
	printf("\n");
	printf("\n");
/* End of the else block. This one will be what is ran if PROMPT is not defined, and then the program will end */
#endif
	return(0);		/* where both if and else blocks end at after they are executed */
}

