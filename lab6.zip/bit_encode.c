/*******************************\
* JIYT bit stream encoder	*
\*******************************/
#include <stdio.h>
unsigned char rotate_right(unsigned char value);
unsigned char rotate_left(unsigned char value);
unsigned int create_key();

int main()
{
char 	      cleartext_in[500];
unsigned char ciphertext[500];
int  	      i, ofst, col, length;
unsigned int cur_in, key;

    printf("enter cleartext: ");
    cur_in = getchar();
    ofst = 0;
    while ( ((int)cur_in >=0) && (cur_in != '\n') )
    {
	cleartext_in[ofst] = (char)cur_in;
	cur_in = getchar();
	ofst++;
    }
    cleartext_in[ofst] = 0;
    length = ofst;
    printf("%s\n", cleartext_in);

/***************************************\
* print ASCII hex encoding		*
\***************************************/
    printf("hex encoding:\n\t");
    col  = 0;
    for ( ofst = 0; ofst < length; ofst++ )
    {
	if ( col == 10 )
	{
	    printf("\n\t");
	    col = 0;
	}
	printf("%.2X ", (unsigned int)cleartext_in[ofst]);
	col++;
    }
    printf("\n");
    key = create_key();

    for ( ofst = 0; ofst < length; ofst++ )
    {
	ciphertext[ofst] = cleartext_in[ofst] ^ key;
	if(ofst%2){	/* if index is odd	*/
		ciphertext[ofst] = rotate_right(ciphertext[ofst]);
	}
	else {		/* index is even	*/
		ciphertext[ofst] = rotate_left(ciphertext[ofst]);
	}
    }

    col = 0;
    printf("hex ciphertext:\n\t");
    for ( ofst = 0; ofst < length; ofst++ )
    {
	if ( col == 10 )
	{
	    printf("\n\t");
	    col = 0;
	}
	printf("%.2X ", (unsigned int)ciphertext[ofst]);
	col++;
    }
    printf("\n");
return(0);
}

